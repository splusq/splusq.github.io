﻿using System.ComponentModel.Composition;
using System.Net;

namespace Service.Contracts
{
    [InheritedExport]
    public interface IPipeline
    {
        void Continue(HttpListenerContext listenerContext);
    }
}
