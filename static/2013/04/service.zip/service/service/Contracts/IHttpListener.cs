﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Net;
using System.Threading.Tasks;

namespace Service.Contracts
{
    [InheritedExport]
    public interface IHttpListener
    {
        ICollection<string> Prefixes { get; }

        Task<HttpListenerContext> GetContextAsync();

        void Start();
    }
}
