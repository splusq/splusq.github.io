﻿using Service.Contracts;
using System.Net;

namespace Service.Pipeline
{
    public class TerminatingPipeline : IPipeline
    {
        public void Continue(HttpListenerContext listenerContext)
        {
            // end the response stream
            listenerContext.Response.Close();

            // no more forwarding
        }
    }
}
