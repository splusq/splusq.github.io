﻿using Service.Contracts;
using System;
using System.Net;

namespace Service.Pipeline
{
    public class LoggingPipeline : BaseContinuationPipeline
    {
        public LoggingPipeline(IPipeline forward) : base(forward) { }

        protected override void Execute(HttpListenerContext listenerContext)
        {
            Console.WriteLine(listenerContext.Request.Url);
        }
    }
}
