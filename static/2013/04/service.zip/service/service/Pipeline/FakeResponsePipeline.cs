﻿using Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Service.Pipeline
{
    public class FakeResponsePipeline : BaseContinuationPipeline
    {
        protected override void Execute(HttpListenerContext listenerContext)
        {
            string response = "this is a fake pipeline";
            listenerContext.Response.OutputStream.WriteAsync(ASCIIEncoding.ASCII.GetBytes(response), 0, response.Length);
        }
    }
}
