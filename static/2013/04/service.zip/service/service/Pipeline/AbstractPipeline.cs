﻿using Service.Contracts;
using System.Net;
using System.Threading.Tasks;

namespace Service.Pipeline
{
    public abstract class BaseContinuationPipeline : IPipeline
    {
        private IPipeline forward;

        public BaseContinuationPipeline()
        {
            // default is the terminating pipeline
            this.forward = new TerminatingPipeline(); 
        }
        
        public BaseContinuationPipeline(IPipeline forward)
        {
            this.forward = forward;
        }

        public virtual void Continue(HttpListenerContext listenerContext)
        {
            Task.Run(() =>
            {
                // execute the action
                this.Execute(listenerContext);

                // continue to the next action
                this.forward.Continue(listenerContext);
            });
        }

        protected abstract void Execute(HttpListenerContext listenerContext);
    }
}
