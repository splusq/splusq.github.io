﻿using Service.Contracts;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Service.Adapters
{
    public class HttpListenerAdapter : IHttpListener
    {
        private readonly HttpListener listener;

        public HttpListenerAdapter()
        {
            this.listener = new HttpListener();
        }

        public ICollection<string> Prefixes
        {
            get { return this.listener.Prefixes; }
        }

        public Task<HttpListenerContext> GetContextAsync()
        {
            return this.listener.GetContextAsync();
        }

        public void Start()
        {
            this.listener.Start();
        }
    }
}
