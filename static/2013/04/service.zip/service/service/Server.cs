﻿using Service.Contracts;
using System.ComponentModel.Composition;
using System.Threading.Tasks;

namespace Service
{
    [Export]
    public class Server
    {
        private readonly IHttpListener listener;
        private readonly IPipeline pipeline;

        [ImportingConstructor]
        public Server(IHttpListener listener, IPipeline pipeline)
        {
            this.listener = listener;
            this.pipeline = pipeline;
        }

        public async Task Start(string address)
        {
            this.listener.Prefixes.Add(address);
            this.listener.Start();

            // keep listening
            while (true)
            {
                // wait for a listener
                var context = await this.listener.GetContextAsync().ConfigureAwait(false);

                // initiate the pipeline and forget
                this.pipeline.Continue(context);
            }
        }
    }
}
