﻿using Service.Contracts;
using Service.Pipeline;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition;
using System;

namespace Service
{
    public sealed class Program
    {
        static void Main(string[] args)
        {
            // configure the MEF container
            using (var container = ConfigureMef())
            {
                // create a pipeline flow - logging/fake response/terminate
                IPipeline pipeline = new LoggingPipeline(new FakeResponsePipeline());

                // inject the property
                container.ComposeExportedValue<IPipeline>(pipeline);

                // resolve the root type
                var server = container.GetExportedValue<Server>();

                // start the server
                var service = server.Start(@"http://127.0.0.1:8080/");

                // keep accepting connections
                service.Wait();
            } // dispose
        }

        private static CompositionContainer ConfigureMef()
        {
            // build a default aggregatecatalog
            var catalog = new AggregateCatalog();

            // add the current assembly to the catalog
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));

            // return the container
            return new CompositionContainer(catalog);
        }
    }
}
