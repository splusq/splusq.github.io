﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SuperSocket.Common;
using SuperSocket.SocketBase.Command;

namespace SuperWebSocket.Protocol
{
    public interface IWebSocketFragment : ICommandInfo
    {

    }
}
