﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("SuperWebSocket")]
[assembly: AssemblyProduct("SuperWebSocket")]
[assembly: AssemblyCopyright("Copyright © SuperWebSocket 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.6.0.0")]
[assembly: AssemblyFileVersion("0.6.0.0")]
