﻿var dataContext = function (vm) {
    var self = this;
    var init = false;
    var status = $("#status");

    status.append(writeLine("Initializing: server..."));
    
    $.getJSON("/Service/Api/Attach/" + vm, function () {
        connectSocketServer(function (e) {
            self.update(e.data);
        })
    });

    this.update = function (d) {
        if (!init) {
            ko.mapping.fromJSON(d, {}, self);
            ko.applyBindings(self);
            init = true;
        }
        ko.mapping.fromJSON(d, {}, self);
    }
};

function writeLine(message) {
    return "[] " + message + "\n";
}

function connectSocketServer(ondata) {
    var support = "MozWebSocket" in window ? "MozWebSocket" : ("WebSocket" in window ? "WebSocket" : null);

    if (support == null) {
        alert("Browser does not support web-sockets");
        return;
    }
    connect("ws://localhost:4502/service/", support, ondata);
    //connect("wss://localhost:4503/service", support);
}

function connect(url, support, ondata) {
    var status = $("#status");
    var first = true;

    var ws = new window[support](url);

    ws.onmessage = function (evt) {
        if (first) {
            status.append(writeLine("Received: " + evt.data));
            first = false;
        }
        else {
            ondata(evt);
        }
    };

    ws.onopen = function () {
        status.append(writeLine("Connection: open"));
    };

    ws.onclose = function () {
        status.append(writeLine("Connection: closed"));
    }
}