﻿using Newtonsoft.Json;

namespace Service.Data
{
    public class ProcessMetadata
    {
        [JsonProperty]
        public string Name { get; set; }

        [JsonProperty]
        public string Memory { get; set; }

        public ProcessMetadata(string name, string memory)
        {
            this.Name = name;
            this.Memory = memory;
        }
    }
}