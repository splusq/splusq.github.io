﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Service.Shared;
using SuperWebSocket;
using SuperWebSocket.SubProtocol;

namespace Service.ViewModels
{
    public class BaseViewModel
    {
        private object sync = new object();

        protected void RaiseAndSetProperty<T>(ref T backingField, T value, [CallerMemberName] string propertyName = "")
        {
            lock (sync)
            {
                if (!backingField.Equals(value))
                {
                    backingField = value;

                    string json;

                    if (typeof(T).IsValueType)
                    {
                        json = new JObject() { new JProperty(propertyName, value) }.ToString();
                    }
                    else
                    {
                        json = JObject.FromObject(new { Node = value }).ToString();
                    }

                    SessionManager.Current.SendToAll(json);
                }
            }
        }
    }
}