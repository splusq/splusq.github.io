﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Service.Data;

namespace Service.ViewModels
{
    public class TaskViewModel : BaseViewModel
    {
        private Timer timer;
        private int counter;
        private Process[] runningProcesses;
        private IList<ProcessMetadata> taskList;
        public IList<ProcessMetadata> TaskList
        {
            get
            {
                return taskList;
            }
            set
            {
                RaiseAndSetProperty<IList<ProcessMetadata>>(ref taskList, value);
            }
        }

        public TaskViewModel()
        {
            taskList = new List<ProcessMetadata>();
            timer = new Timer(updateTasks, null, 2000, 1000);
        }

        private void updateTasks(Object state)
        {
            runningProcesses = Process.GetProcesses();
            TaskList = runningProcesses.
                OrderByDescending(p => p.WorkingSet64).
                ThenBy(p => p.ProcessName).
                Select(p => new ProcessMetadata(p.ProcessName, String.Format("{0:n0} KB", (p.WorkingSet64/1024)))).
                Take(5).
                ToList();

            if (++counter >= 10)
            {
                timer.Change(Timeout.Infinite, Timeout.Infinite);
                timer.Dispose();
            }
        }
    }
}