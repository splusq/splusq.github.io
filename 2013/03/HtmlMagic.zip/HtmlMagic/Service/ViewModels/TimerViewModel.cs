﻿using System;
using System.Threading;

namespace Service.ViewModels
{
    public class TimerViewModel : BaseViewModel
    {
        private Timer timer;

        private int counter;
        public int Counter
        {
            get
            {
                return counter;
            }
            set
            {
                RaiseAndSetProperty<int>(ref counter, value);
            }
        }

        public TimerViewModel()
        {
            timer = new Timer(updateCounter, null, 2000, 1000);
        }

        private void updateCounter(Object state)
        {
            Counter++;

            if (Counter > 9) timer.Dispose();
        }
    }
}