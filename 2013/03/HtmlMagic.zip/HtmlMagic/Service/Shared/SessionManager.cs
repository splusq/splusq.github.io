﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;
using SuperSocket.SocketBase;
using SuperSocket.SocketEngine;
using SuperSocket.SocketEngine.Configuration;
using SuperWebSocket;

namespace Service.Shared
{
    public class SessionManager : IDisposable
    {
        private List<WebSocketSession> sessions = new List<WebSocketSession>();
        private List<WebSocketSession> secureSessions = new List<WebSocketSession>();
        private object sessionSync = new object();
        private object secureSessionSync = new object();

        #region Singleton Instance
        public static SessionManager Current
        {
            get
            {
                return Nested.instance;
            }
        }
        internal class Nested
        {
            static Nested() { }
            internal static readonly SessionManager instance = new SessionManager();
        }

        private SessionManager()
        {
        }
        #endregion

        public void Initialize()
        {
            Activate();
        }

        private void Activate()
        {
            var serverConfig = ConfigurationManager.GetSection("socketServer") as SocketServiceConfig;
            if (!SocketServerManager.Initialize(serverConfig))
                return;

            var socketServer = SocketServerManager.GetServerByName("SuperWebSocket") as WebSocketServer;
            var secureSocketServer = SocketServerManager.GetServerByName("SecureSuperWebSocket") as WebSocketServer;

            socketServer.NewMessageReceived += new SessionEventHandler<WebSocketSession, string>(socketServer_NewMessageReceived);
            socketServer.NewSessionConnected += new SessionEventHandler<WebSocketSession>(socketServer_NewSessionConnected);
            socketServer.SessionClosed += new SessionEventHandler<WebSocketSession, CloseReason>(socketServer_SessionClosed);

            secureSocketServer.NewSessionConnected += new SessionEventHandler<WebSocketSession>(secureSocketServer_NewSessionConnected);
            secureSocketServer.SessionClosed += new SessionEventHandler<WebSocketSession, CloseReason>(secureSocketServer_SessionClosed);

            if (!SocketServerManager.Start())
                SocketServerManager.Stop();
        }

        private void socketServer_NewMessageReceived(WebSocketSession session, string e)
        {
            //SendToAll(session.Cookies["name"] + ": " + e);
        }

        private void secureSocketServer_SessionClosed(WebSocketSession session, CloseReason reason)
        {
            lock (secureSessionSync)
            {
                secureSessions.Remove(session);
            }
        }

        private void secureSocketServer_NewSessionConnected(WebSocketSession session)
        {
            lock (secureSessionSync)
            {
                secureSessions.Add(session);
            }
        }

        private void socketServer_NewSessionConnected(WebSocketSession session)
        {
            lock (sessionSync)
                sessions.Add(session);
            
            SendToAll(String.Format("connected: {0}", session.GetHashCode()));
        }

        private void socketServer_SessionClosed(WebSocketSession session, CloseReason reason)
        {
            lock (sessionSync)
                sessions.Remove(session);

            if (reason == CloseReason.ServerShutdown)
                return;

            SendToAll(String.Format("disconnected: {0}", session.GetHashCode()));
        }

        public void SendToAll(string message)
        {
            lock (sessionSync)
            {
                foreach (var s in sessions)
                {
                    s.SendResponseAsync(message);
                }
            }
        }

        public void Dispose()
        {
            SocketServerManager.Stop();
        }
    }
}