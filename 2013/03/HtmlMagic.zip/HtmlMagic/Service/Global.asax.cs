﻿﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using Service.Shared;
using SuperSocket.Common;

namespace Service
{
    public class Global : System.Web.HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            LogUtil.Setup();
            SessionManager.Current.Initialize();
        }

        void Application_End(object sender, EventArgs e)
        {
            SessionManager.Current.Dispose();
        }
    }
}