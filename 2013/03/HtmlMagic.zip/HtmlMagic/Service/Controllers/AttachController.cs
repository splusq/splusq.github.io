﻿using System;
using System.Web.Http;

namespace Service.Controllers
{
    public class AttachController : ApiController
    {
        public bool Get(string id)
        {
            Activator.CreateInstance(Type.GetType(id));
            return true;
        }
    }
}