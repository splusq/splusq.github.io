﻿using System;
using System.IO;
using System.Text;

namespace prep
{
    class Program
    {
        static void Main(string[] args)
        {
            const string dataDirectory = @"..\..\..\..\data";
            int files = Int32.Parse(args[0]);

            for (int i = 0; i < files; ++i)
            {
                byte[] data = Generate();                
                using (FileStream stream = File.Open(Path.Combine(dataDirectory, String.Format("input{0}.txt", i.ToString().PadLeft(3, '0'))), FileMode.OpenOrCreate))
                {
                    stream.Write(data, 0, data.Length);
                }
            }
        }

        static byte[] Generate()
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            Random random = new Random((int)(DateTime.UtcNow.Ticks % Int32.MaxValue) + 1);
            int maxNumbers = random.Next(10000, 30000);

            StringBuilder data = new StringBuilder();

            for (long i = 0; i < maxNumbers; ++i)
            {
                data.AppendLine(random.NextDouble().ToString("F7"));
            }

            data.Append(random.NextDouble().ToString("F7"));

            return encoding.GetBytes(data.ToString());
        }
    }
}
