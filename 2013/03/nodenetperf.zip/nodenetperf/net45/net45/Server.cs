﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace net45
{
    public class Server
    {
        private readonly HttpListener listener;
        private readonly ASCIIEncoding encoding;
        private const string dataDirectory = @"..\..\..\..\data";
        private const int maxfiles = 550;

        public Server(string address)
        {
            this.encoding = new ASCIIEncoding();
            this.listener = new HttpListener();
            this.listener.Prefixes.Add(address);
            this.listener.Start();
        }

        public async Task Start()
        {
            while (true)
            {
                var context = await this.listener.GetContextAsync();
                this.ProcessRequest(context);
            }
        }
        private string GetFileFromUrl(string url)
        {
            var file = 1;

            if (!String.IsNullOrEmpty(url)) file = (Int32.Parse(url) % maxfiles);

            return String.Format("input{0}.txt", file.ToString().PadLeft(3, '0'));
        }
        private async void ProcessRequest(HttpListenerContext context)
        {
            try
            {
                var filename = this.GetFileFromUrl(context.Request.Url.PathAndQuery.Substring(1));
                string rawData = string.Empty;

                using (StreamReader reader = new StreamReader(Path.Combine(dataDirectory, filename)))
                {
                    rawData = await reader.ReadToEndAsync();
                }
                
                var sorted = await this.SortAsync(context, rawData);
                var response = encoding.GetBytes(String.Format("{0}\t{1}", filename, sorted[sorted.Length / 2]));

                await context.Response.OutputStream.WriteAsync(response, 0, response.Length);
                context.Response.StatusCode = (int)HttpStatusCode.OK;
            }
            catch(Exception e) 
            {
                context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                Console.WriteLine(e.Message);
            }
            finally
            {
                context.Response.Close();
            }
        }

        private async Task<string[]> SortAsync(HttpListenerContext context, string rawData)
        {
            return await Task.Factory.StartNew(() =>
            {
                var array = rawData.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                Array.Sort(array);

                return array;
            });
        }

        static void Main(string[] args)
        {
            const string address = "http://127.0.0.1:8080/";
            var program = new Server(address);
            program.Start().Wait();
        }
    }
}
